// JS minimal pour login/register/dashboard
const API = 'http://localhost:3000/api';
// à compléter : fetch / JWT / interaction avec backend
